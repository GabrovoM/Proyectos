package com.dawes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebApiRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebApiRestApplication.class, args);
	}

}
